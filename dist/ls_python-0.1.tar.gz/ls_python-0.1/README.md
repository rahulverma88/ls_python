# ls_python
Python implementation of level set library
