#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jun  6 10:21:12 2020

@author: rahul
"""

class Options:
    def __init__(self):
        self.factorCFL = 0.5
        self.maxStep = 0.1